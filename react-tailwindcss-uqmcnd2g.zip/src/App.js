import React from "react";
import VacanzaGita from "./VacanzaGita";

export default function App() {
  return <VacanzaGita />;
}
